<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubjectReport extends Model
{
    //
}
