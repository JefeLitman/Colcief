<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Score extends Model
{
    protected $primaryKey = 'id_score';
    protected $fillable = ['id_score','name', 'percentage', 'description'];
    
    //relacion con periods
    public function periods(){ 
    	return $this->belongsToMany('App\Period');
    }
 	//relacion con divisions
    public function divisions(){ 
    	return $this->belongsToMany('App\Division');
    }

    public function subjectTC(){ 
    	return $this->belongsToMany('App\Score');
    }

    public function studentScores(){ 
    	return $this->hasMany('App\StudentScores');
    }

}
