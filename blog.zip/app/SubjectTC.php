<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubjectTC extends Model
{
    protected $primaryKey = 'id_subject';
    protected $fillable = ['id_subject','name', 'classroom'];
    
    //relacion con subject_teacher_course
    public function schedules(){ 
    	return $this->hasMany('App\Schedule');
    }

    public function subjectReport(){ 
    	return $this->hasMany('App\SubjectReport');
    }

    public function scores(){ 
    	return $this->hasMany('App\Score');
    }

    public function subject(){ 
    	return $this->belongsToMany('App\Subject');
    }

    public function employee(){ 
    	return $this->belongsToMany('App\Employee');
    }

    public function grades(){ 
    	return $this->belongsToMany('App\Grade');
    }
}
