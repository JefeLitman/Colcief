<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-4 col-md-offset-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h1 class="panel-title">Welcome <?php echo e(auth()->user()->name); ?></h1>
      </div>
      <div class="panel-body">
        <strong>Email: </strong><?php echo e(auth()->user()->email); ?>

      </div>
      <div class="panel-footer">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo e(csrf_field()); ?>

          <button class="btn btn-danger btn-xs btn-block">Logout</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>