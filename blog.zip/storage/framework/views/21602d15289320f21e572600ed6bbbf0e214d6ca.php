<?php $__env->startSection('content'); ?>
<?php if(session()->has('flash')): ?>
	<div class="alert alert-info"><?php echo e(session('flash')); ?></div>
<?php endif; ?>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h1 class="panel-title">Acceso a la aplicación</h1>
				</div>
				<div class="panel-body">
					<form method="POST" action="<?php echo e(route('autentication')); ?>">
						<?php echo e(csrf_field()); ?>

						<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
							<label for="email">Email</label>
							<input class="form-control" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>">
							<?php echo $errors -> first('email','<span class="help-block">:message</span>'); ?>

						</div>
						<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
							<label for="password">Password</label>
							<input class="form-control" id="password" type="password" name="password">
							<?php echo $errors -> first('password','<span class="help-block">:message</span>'); ?>

						</div>
						<button class="btn btn-primary btn-block">Login</button>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>